#include <chrono>
#include <memory>
#include "rclcpp/rclcpp.hpp"
//#include "eco_ros_lib/msg/num.hpp"     // CHANGE
#include "eco_ros_lib/msg/eco_gps_gpfpd.hpp"     // CHANGE
#include <std_msgs/msg/float64.hpp>
#include <std_msgs/msg/u_int8.hpp>
#include <geometry_msgs/msg/pose.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <geometry_msgs/msg/pose_with_covariance_stamped.hpp>
#include <geometry_msgs/msg/point.hpp>
#include <geometry_msgs/msg/quaternion.hpp>
#include <geometry_msgs/msg/pose2_d.hpp>
#include <sensor_msgs/msg/nav_sat_fix.hpp>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <tf2_ros/transform_broadcaster.h>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2/transform_datatypes.h>
#include <math.h>
#include <iostream>
#include <exception>
#include <string>
#include <GeographicLib/UTMUPS.hpp>
#include <GeographicLib/MGRS.hpp>

using namespace std::chrono_literals;
using std::placeholders::_1;
using namespace GeographicLib;
using namespace std;

#define PI 3.1415926535897932846
double gnss_2_utm_station_x = 0.0;
double gnss_2_utm_station_y = 0.0;
int gnss_2_utm_epsg = 0;

double model_car_x = 0.0;
double model_car_y = 0.0;
double model_car_z = 0.0;
size_t count_=0;

geometry_msgs::msg::Quaternion createQuaternionMsgFromYaw(double yaw)
{
  tf2::Quaternion q;
  q.setRPY(0,0,yaw);
  return tf2::toMsg(q);
}

class Gnss_2_Utm_Node : public rclcpp::Node
{
public:
  Gnss_2_Utm_Node()
  : Node("gnss_2_utm")
  {
    gnss_sub = this->create_subscription<eco_ros_lib::msg::EcoGpsGpfpd>("/EcoGpsGpfpd",10,std::bind(&Gnss_2_Utm_Node::gnss_callback, this, _1));
    pose_pub = this->create_publisher<geometry_msgs::msg::PoseStamped>("/pose", 1);    // CHANGE
  }

  void gnss_callback(const eco_ros_lib::msg::EcoGpsGpfpd::SharedPtr gnss_msg) const       // CHANGE
  {
    geometry_msgs::msg::PoseStamped pose;
    double lat, lon;
    lat = gnss_msg->lattitude;
    lon = gnss_msg->longitude;
    int zone;
    bool northp;
    double x, y;
    UTMUPS::Forward(lat, lon, zone, northp, x, y);
    string mgrs;
    MGRS::Forward(zone, northp, x, y, lat, 10, mgrs);
    string aa ,bb;
    aa = mgrs.substr(5,10);
    bb = mgrs.substr(15,24);
    char *aax = (char*)aa.c_str();
    char *bby = (char*)bb.c_str();
    double ax = atof(aax);
    double by = atof(bby);
    ax = ax * 0.00001;
    by = by * 0.00001;
    pose.pose.position.x = ax;
    pose.pose.position.y = by;
    double heading_ = -1 * gnss_msg->heading * PI / 180.0 + PI / 2;
    pose.pose.orientation = createQuaternionMsgFromYaw(heading_);
    pose_pub->publish(pose);	
  }

private:
  rclcpp::Subscription<eco_ros_lib::msg::EcoGpsGpfpd>::SharedPtr gnss_sub;
  rclcpp::Publisher<geometry_msgs::msg::PoseStamped>::SharedPtr pose_pub;         // CHANGE
  
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  RCLCPP_INFO(rclcpp::get_logger("gnss_2_utm"), "Log In Gnss_2_Utm Success!!!!!!!");    // CHANGE
  rclcpp::spin(std::make_shared<Gnss_2_Utm_Node>());
  rclcpp::shutdown();
  return 0;
}
