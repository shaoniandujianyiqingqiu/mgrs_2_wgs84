#ifndef ECO_ROS_LIB__VISIBILITY_CONTROL_H_
#define ECO_ROS_LIB__VISIBILITY_CONTROL_H_
#if defined _WIN32 || defined __CYGWIN__
  #ifdef __GNUC__
    #define ECO_ROS_LIB_EXPORT __attribute__ ((dllexport))
    #define ECO_ROS_LIB_IMPORT __attribute__ ((dllimport))
  #else
    #define ECO_ROS_LIB_EXPORT __declspec(dllexport)
    #define ECO_ROS_LIB_IMPORT __declspec(dllimport)
  #endif
  #ifdef ECO_ROS_LIB_BUILDING_LIBRARY
    #define ECO_ROS_LIB_PUBLIC ECO_ROS_LIB_EXPORT
  #else
    #define ECO_ROS_LIB_PUBLIC ECO_ROS_LIB_IMPORT
  #endif
  #define ECO_ROS_LIB_PUBLIC_TYPE ECO_ROS_LIB_PUBLIC
  #define ECO_ROS_LIB_LOCAL
#else
  #define ECO_ROS_LIB_EXPORT __attribute__ ((visibility("default")))
  #define ECO_ROS_LIB_IMPORT
  #if __GNUC__ >= 4
    #define ECO_ROS_LIB_PUBLIC __attribute__ ((visibility("default")))
    #define ECO_ROS_LIB_LOCAL  __attribute__ ((visibility("hidden")))
  #else
    #define ECO_ROS_LIB_PUBLIC
    #define ECO_ROS_LIB_LOCAL
  #endif
  #define ECO_ROS_LIB_PUBLIC_TYPE
#endif
#endif  // ECO_ROS_LIB__VISIBILITY_CONTROL_H_
// Generated 24-Nov-2023 14:08:21
 